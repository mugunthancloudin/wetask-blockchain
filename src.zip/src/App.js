import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import LandingPage from './pages/landingPage';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import Layout from './components/create/layouts/layout';
import CampDashboard from './components/create/campaign/campDashboard/campDashboard';


function App() {
  return (
    <>
    <BrowserRouter>
        <Routes>
        <Route path='/df' element={<LandingPage/>} />
        <Route path='/jjl' element={<Layout/>} />
        <Route path='/' element={<CampDashboard/>} />

        </Routes>
    </BrowserRouter>
    </>
  );
}

export default App;
