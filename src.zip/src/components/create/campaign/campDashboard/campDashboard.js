import React from "react";
import SideNav from "../../sidenav/sidenav";
import Basicinfo from "../campModule/basicinfo";
import Eligiblity from "../campModule/eligiblity";
import Rewards from "../campModule/rewards";
import Task from "../campModule/task";
import { Route, Routes } from 'react-router-dom';
import CampSideNav from "./campSideNav";

export default function CampDashboard() {
  return (
    <>
      <div className="container-fluid">
        <div className="row">
          <div className="col-lg-4 col-md-2">
            <h1>Create Campaign</h1>
            <CampSideNav />
            
          </div>
          <div className="col-lg-8 col-md-10">
            
            <Routes>
              <Route path="/basicInfo" element={<Basicinfo />} />
              <Route path="/campignEligiblity" element={<Eligiblity />} />
              <Route path="/campaignRewards" element={<Rewards />} />
              <Route path="/campaignTasks" element={<Task />} />
            </Routes>
          </div>
        </div>
      </div>
    </>
  );
}
