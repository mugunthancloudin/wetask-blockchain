// navConfig.js
import { FaHome, FaCog, FaUser } from 'react-icons/fa'; // Example icons

const navItems = [
  {
    path: '/basicInfo',
    label: 'Basic Info',
    Icon: FaHome,
  },
  {
    path: '/campaignRewards',
    label: 'Rewards',
    Icon: FaCog,
  },
  {
    path: '/campignEligiblity',
    label: 'Eligiblity',
    Icon: FaHome, 
  },
  {
    path: '/campaignTasks',
    label: 'Tasks',
    Icon: FaCog,
  },
 
];

export default navItems;
