import React from "react";
import "./campaignModule.css";


export default function Eligiblity() {
  return (
    <>
      <h1>eligiblity</h1>
    </>
  );
}
