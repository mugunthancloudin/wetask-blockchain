import React from 'react'
import "./campaignModule.css";

export default function Basicinfo() {
  return (
    <div>
      <h1>basic Info</h1>
    </div>
  )
}
