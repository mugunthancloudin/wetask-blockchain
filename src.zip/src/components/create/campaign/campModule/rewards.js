import React from "react";
import "./campaignModule.css";

export default function Rewards() {
  return (
    <>
      <h1>rewards</h1>
    </>
  );
}
