import React from 'react'

export default function Space() {
  return (
    <>
     <h1>Space</h1> 
    </>
  )
}
