import React from 'react'

export default function Event() {
  return (
    <>
     <h1>event</h1> 
    </>
  )
}
